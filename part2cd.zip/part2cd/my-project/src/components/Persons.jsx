const Persons = ({ persons = [], searchField, setPersons }) => {
  if (!Array.isArray(persons)) {
    console.error('persons is not an array', persons);
    return null;
  }

  const deletePersonOf = (id) => {
    const person = persons.find((n) => n.id === id);

    
    
    personService
      .remove(id)
      .then(() => {
        setPersons(persons.filter((person) => person.id !== id));
      })
      .catch(() => {
        alert(`Person '${person.name}' was already deleted from server`);
        setPersons(persons.filter((n) => n.id !== id));
      });
  };
  const DeleteButton = ({ deletionOfPerson }) => {
    return <button onClick={deletionOfPerson}>Delete</button>;
  };

  return (
    <div>
      {persons
        .filter((person) =>
          person.name.toLowerCase().includes(searchField.toLowerCase())
        )
        .map((person) => (
          <div key={person.name}>
            {person.name} {person.number}
            <DeleteButton deletionOfPerson={() => deletePersonOf(person.id)} />
          </div>
        ))}
    </div>
  );
};

export default Persons;
