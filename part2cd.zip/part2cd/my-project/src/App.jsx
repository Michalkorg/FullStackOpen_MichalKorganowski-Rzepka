import React, { useState, useEffect } from "react"
import Filter from "./components/Filters"
import Notification from "./components/Notification"
import PersonForm from "./components/PersonForm"
import Persons from "./components/Persons"
import personService from "./services/persons"

const App = () => {
  const [persons, setPersons] = useState([])
  const [newName, setNewName] = useState("")
  const [newNumber, setNewNumber] = useState("")
  const [searchField, setSearchField] = useState("")
  const [notifications, setNotifications] = useState(null)

  useEffect(() => {
  personService.getAll().then((initialPersons) => {
    console.log("Otrzymane dane z API:", initialPersons);
    setPersons(initialPersons);  // Nie używaj `.data`, ponieważ `getAll()` już zwraca dane
  }).catch((error) => {
    console.error('Błąd pobierania danych:', error);
  });
}, []);

  

  return (
    <div>
      <h2>Phonebook</h2>

      <Notification notification={notifications} />

      <Filter searchField={searchField} setSearchField={setSearchField} />

      <h3>add a new</h3>

      <PersonForm
        persons={persons}
        setPersons={setPersons}
        newName={newName}
        setNewName={setNewName}
        newNumber={newNumber}
        setNewNumber={setNewNumber}
        setNotifications={setNotifications}
      />

      <h3>Numbers</h3>

      <Persons
        persons={persons}
        searchField={searchField}
        setPersons={setPersons}
      />
    </div>
  )
}

export default App
