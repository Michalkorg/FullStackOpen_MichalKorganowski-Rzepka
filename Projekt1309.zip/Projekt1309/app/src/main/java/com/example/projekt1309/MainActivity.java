package com.example.projekt1309;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        //Metoda Log.d(tag,msg) ma dwa argumenty typowy string
        // a R.string.glowny_tekst jest identyfikatorem a nie stringem
        Log.d( "Id Napis", String.valueOf(R.string.glowny_tekst)); //id
        Log.d("Napis", getResources(). getString(R.string.glowny_tekst));

        String[] zawody = getResources().getStringArray(R.array.zawody);
        for(String zawod:zawody){
            Log.d("Zawód", zawod);
        }
        };
    }
